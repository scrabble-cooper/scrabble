package com.scrabble.jdbc.update_points;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScrabbleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScrabbleApplication.class, args);
	}

}
